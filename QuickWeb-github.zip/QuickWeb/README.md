# QuickWeb 1.0 – Super-fast browser for Galaxy Watch 7

Standalone Wear OS browser optimised for a round 1.5" display.

## Features
- Fast WebView with mobile Chrome user-agent (desktop mode toggle)
- Homepage with quick links (Google, DuckDuckGo, Wikipedia, YouTube, Reddit, X, Maps, News)
- Search-or-URL bar (DuckDuckGo for free-text, auto-https for domains)
- Bookmarks (tap ★ or long-press page) – stored locally, max 30
- Back / Forward / Reload / Home / **Zoom − +** / More menu
- Fully functional zoom:
  - Pinch-to-zoom (built-in WebView)
  - Explicit **+** / **−** toolbar buttons
  - Text size larger/smaller (persisted)
  - Reset zoom
  - Live zoom percentage toast
- Progress bar, network error handling
- Handles `http`/`https` VIEW intents – any link on the watch can open in QuickWeb
- Dark high-contrast UI, large touch targets, battery-friendly (no background polling)
- Zero external libraries – pure Java + platform WebView

## Build (on your Mac)
```bash
unzip QuickWeb.zip
cd QuickWeb
chmod +x build.sh
./build.sh
```
Produces `QuickWeb.apk` in the project root.

Requirements: JDK 17–23 and the Android SDK (`~/Library/Android/sdk`). Gradle 8.10.2 is downloaded
automatically to `~/gradle` if no suitable one is installed (AGP 8.5.2 does **not** work with Gradle 9.x).
Opening the folder in Android Studio also works (uses `gradle/wrapper/gradle-wrapper.properties`).

Install over Wi-Fi:
```bash
./build.sh install
```

## Install on Galaxy Watch 7 (ADB wireless)
1. Watch: Settings → About → Software → tap Build number 7× → Developer options  
2. Developer options → ADB debugging ON + Wireless debugging ON  
3. Wireless debugging → Pair new device → note IP:PORT + pairing code  
4. Mac: `adb pair <ip>:<pairing-port>` (enter code)  
5. Mac: `adb connect <ip>:<connect-port>`  
6. `./build.sh install`   (or `adb install -r QuickWeb.apk`)

## Logo
Cyan speed-arc + white lightning bolt on dark navy – “quick & web”.

## Notes
- First build downloads AGP; subsequent builds are fast.
- Cleartext (http) allowed for compatibility; prefer https.
- YouTube / complex sites work but are limited by the small screen and watch CPU.
