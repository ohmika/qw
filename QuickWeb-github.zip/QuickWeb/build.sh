#!/usr/bin/env bash
# QuickWeb build script (macOS, zsh/bash 3.2 compatible, no GUI, no prompts).
#
#   chmod +x build.sh && ./build.sh            build QuickWeb.apk
#   ./build.sh install                         build, then install over adb (Wi-Fi) and start the app
#   ./build.sh wrapper                         (optional) also generate gradlew + gradle-wrapper.jar
#
# Gradle 8.10.2 is downloaded automatically to ~/gradle when no suitable Gradle is installed.
# Environment overrides: ANDROID_HOME, ADB_SERIAL=<ip:port or serial> (when several devices are connected)
set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="QuickWeb"
PKG="com.mika.quickweb"
COMPILE_SDK="34"          # keep in sync with app/build.gradle
BUILD_TOOLS="34.0.0"      # keep in sync with app/build.gradle
GRADLE_VERSION="8.10.2"
MODE="${1:-build}"
TOTAL=6

step() { echo ""; echo "[$1/$TOTAL] $2"; }

fail() {
  echo "" >&2
  echo "BUILD FAILED during: $1" >&2
  echo "Likely fix: $2" >&2
  exit 1
}

# ---- [1/6] Java 17+ ----------------------------------------------------------------------------
step 1 "Checking Java (17-23) ..."
JAVA_HOME_FOUND=""
if [ -x /usr/libexec/java_home ]; then
  for v in 17 21; do
    JAVA_HOME_FOUND="$(/usr/libexec/java_home -v "$v" 2>/dev/null || true)"
    if [ -n "$JAVA_HOME_FOUND" ]; then break; fi
  done
fi
if [ -z "$JAVA_HOME_FOUND" ] && [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
  JAVA_HOME_FOUND="$JAVA_HOME"
fi
[ -n "$JAVA_HOME_FOUND" ] || fail "finding a JDK" "Install: brew install --cask temurin@17"
export JAVA_HOME="$JAVA_HOME_FOUND"
export PATH="$JAVA_HOME/bin:$PATH"
JAVA_LINE="$("$JAVA_HOME/bin/java" -version 2>&1 | head -n 1 || true)"
JAVA_MAJOR="$(printf '%s\n' "$JAVA_LINE" | awk -F'"' '{split($2,a,"."); print (a[1]=="1" ? a[2] : a[1]); exit}')"
case "$JAVA_MAJOR" in
  17|18|19|20|21|22|23) ;;
  *) fail "checking the JDK version (found: ${JAVA_MAJOR:-unknown})" \
          "Gradle $GRADLE_VERSION needs JDK 17-23. Install: brew install --cask temurin@17" ;;
esac
echo "JAVA_HOME=$JAVA_HOME"
echo "$JAVA_LINE"

# ---- [2/6] Android SDK + local.properties ------------------------------------------------------
step 2 "Checking Android SDK ..."
ANDROID_HOME="${ANDROID_HOME:-$HOME/Library/Android/sdk}"
[ -d "$ANDROID_HOME" ] || fail "finding the Android SDK ($ANDROID_HOME)" \
  "Set ANDROID_HOME to your SDK folder (normally ~/Library/Android/sdk) in ~/.zshrc"
export ANDROID_HOME
export ANDROID_SDK_ROOT="$ANDROID_HOME"
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
echo "ANDROID_HOME=$ANDROID_HOME"
echo "local.properties written"

SDKMANAGER=""
for candidate in "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" \
                 "$ANDROID_HOME"/cmdline-tools/*/bin/sdkmanager \
                 "$ANDROID_HOME/tools/bin/sdkmanager"; do
  if [ -x "$candidate" ]; then SDKMANAGER="$candidate"; break; fi
done
if [ -z "$SDKMANAGER" ] && command -v sdkmanager >/dev/null 2>&1; then
  SDKMANAGER="$(command -v sdkmanager)"
fi

# ---- [3/6] SDK packages ------------------------------------------------------------------------
step 3 "Checking SDK packages (platform android-$COMPILE_SDK, build-tools $BUILD_TOOLS) ..."
if [ ! -f "$ANDROID_HOME/licenses/android-sdk-license" ] && [ -n "$SDKMANAGER" ]; then
  echo "Accepting SDK licenses ..."
  yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1 || true
fi
if [ ! -f "$ANDROID_HOME/platforms/android-$COMPILE_SDK/android.jar" ] || [ ! -d "$ANDROID_HOME/build-tools/$BUILD_TOOLS" ]; then
  [ -n "$SDKMANAGER" ] || fail "installing SDK packages" \
    "sdkmanager not found. Install the cmdline-tools into $ANDROID_HOME/cmdline-tools/latest"
  echo "Installing missing SDK packages with sdkmanager ..."
  yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1 || true
  "$SDKMANAGER" --sdk_root="$ANDROID_HOME" "platforms;android-$COMPILE_SDK" "build-tools;$BUILD_TOOLS" \
    || fail "installing SDK packages" \
       "Check the Wi-Fi/network, then run: yes | sdkmanager --licenses  and retry"
fi
echo "Platform android-$COMPILE_SDK and build-tools $BUILD_TOOLS are present"

# ---- [4/6] Gradle ------------------------------------------------------------------------------
step 4 "Locating Gradle $GRADLE_VERSION ..."

# AGP 8.5.2 needs Gradle 8.7+ and does NOT work with Gradle 9.x, so a random 'gradle' on the PATH
# is only accepted when it is an 8.x release >= 8.7.
gradle_ok() {
  local v
  v="$("$1" --version 2>/dev/null | awk '/^Gradle /{print $2; exit}' || true)"
  case "$v" in
    8.[7-9]|8.[7-9].*|8.[1-9][0-9]|8.[1-9][0-9].*) return 0 ;;
  esac
  return 1
}

GRADLE_DIR="$HOME/gradle/gradle-$GRADLE_VERSION"
GRADLE_BIN=""
if [ -x ./gradlew ] && [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  GRADLE_BIN="./gradlew"
elif [ -x "$GRADLE_DIR/bin/gradle" ]; then
  GRADLE_BIN="$GRADLE_DIR/bin/gradle"
elif command -v gradle >/dev/null 2>&1 && gradle_ok "$(command -v gradle)"; then
  GRADLE_BIN="$(command -v gradle)"
else
  echo "No suitable Gradle found - downloading Gradle $GRADLE_VERSION to $HOME/gradle ..."
  command -v curl  >/dev/null 2>&1 || fail "downloading Gradle" "curl is missing"
  command -v unzip >/dev/null 2>&1 || fail "downloading Gradle" "unzip is missing"
  mkdir -p "$HOME/gradle"
  GZIP_FILE="$HOME/gradle/gradle-$GRADLE_VERSION-bin.zip"
  GURL="https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
  curl -fL --retry 3 -o "$GZIP_FILE" "$GURL" \
    || fail "downloading $GURL" "Check the Wi-Fi/network and retry"
  EXPECTED_SHA="$(curl -fsSL "$GURL.sha256" || true)"
  ACTUAL_SHA="$(shasum -a 256 "$GZIP_FILE" | awk '{print $1}')"
  if [ -n "$EXPECTED_SHA" ] && [ "$EXPECTED_SHA" != "$ACTUAL_SHA" ]; then
    rm -f "$GZIP_FILE"
    fail "verifying the Gradle download (checksum mismatch)" "Retry; if it keeps failing, download Gradle manually"
  fi
  unzip -q -o "$GZIP_FILE" -d "$HOME/gradle" || fail "unzipping Gradle" "Delete $GZIP_FILE and retry"
  rm -f "$GZIP_FILE"
  GRADLE_BIN="$GRADLE_DIR/bin/gradle"
fi
[ -x "$GRADLE_BIN" ] || chmod +x "$GRADLE_BIN" 2>/dev/null || true
echo "Using: $GRADLE_BIN"

# Create gradlew + wrapper jar once, so later builds (and other machines) need no manual Gradle.
if [ "$GRADLE_BIN" != "./gradlew" ] && [ "$MODE" != "wrapper" ]; then
  "$GRADLE_BIN" wrapper --gradle-version "$GRADLE_VERSION" --no-daemon --console=plain >/dev/null 2>&1 \
    && echo "Gradle wrapper generated (gradlew)" || true
fi

if [ "$MODE" = "wrapper" ]; then
  echo "Generating Gradle wrapper $GRADLE_VERSION ..."
  "$GRADLE_BIN" wrapper --gradle-version "$GRADLE_VERSION" --no-daemon --console=plain \
    || fail "generating the Gradle wrapper" "Run the build once normally first (./build.sh), then retry"
  echo "Wrapper created. Note: ./gradlew downloads Gradle $GRADLE_VERSION from the internet on first use."
fi

# ---- [5/6] Build -------------------------------------------------------------------------------
step 5 "Building the debug APK (first run downloads the Android Gradle Plugin, this can take a few minutes) ..."
"$GRADLE_BIN" assembleDebug --no-daemon --console=plain \
  || fail "Gradle assembleDebug" \
     "Find the FIRST 'error:' or 'What went wrong' above, and paste the complete output"

# ---- [6/6] Result ------------------------------------------------------------------------------
step 6 "Collecting the APK ..."
APK_SRC="app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK_SRC" ] || fail "finding the built APK" "Gradle finished but $APK_SRC does not exist; check the output above"
cp -f "$APK_SRC" "./$APP_NAME.apk"
APK_PATH="$(pwd)/$APP_NAME.apk"
APK_SIZE="$(du -h "$APK_PATH" | cut -f1)"

APKSIGNER="$ANDROID_HOME/build-tools/$BUILD_TOOLS/apksigner"
if [ -x "$APKSIGNER" ]; then
  "$APKSIGNER" verify "$APK_PATH" && echo "Signature verified" || echo "WARNING: signature check failed"
fi

echo ""
echo "DONE: $APK_PATH ($APK_SIZE)"

# ---- Optional install ----------------------------------------------------------------------------
if [ "$MODE" = "install" ]; then
  echo ""
  echo "Installing over adb ..."
  ADB="$(command -v adb || true)"
  if [ -z "$ADB" ] && [ -x "$ANDROID_HOME/platform-tools/adb" ]; then ADB="$ANDROID_HOME/platform-tools/adb"; fi
  [ -n "$ADB" ] || fail "finding adb" "Install: brew install --cask android-platform-tools"

  SERIAL="${ADB_SERIAL:-}"
  if [ -z "$SERIAL" ]; then
    DEVICES="$("$ADB" devices | awk 'NR>1 && $2=="device" {print $1}' || true)"
    COUNT="$(printf '%s\n' "$DEVICES" | grep -c . || true)"
    if [ "$COUNT" = "1" ]; then
      SERIAL="$DEVICES"
    elif [ "$COUNT" = "0" ]; then
      echo "No device connected. Connect the watch over Wi-Fi first:" >&2
      echo "  1. Watch: Settings > Developer options > ADB debugging ON + Wireless debugging ON" >&2
      echo "  2. Wireless debugging > Pair new device (shows IP:PORT and a pairing code)" >&2
      echo "  3. Mac:   adb pair <ip>:<pairing-port>     (type the code)" >&2
      echo "  4. Mac:   adb connect <ip>:<connect-port>  (port on the main Wireless debugging screen)" >&2
      echo "  5. Mac:   ./build.sh install" >&2
      exit 1
    else
      echo "Several devices found. Choose one:  ADB_SERIAL=<serial> ./build.sh install" >&2
      "$ADB" devices >&2
      exit 1
    fi
  fi

  "$ADB" -s "$SERIAL" install -r "$APK_PATH" \
    || fail "adb install" \
       "If it says INSTALL_FAILED_UPDATE_INCOMPATIBLE: adb -s $SERIAL uninstall $PKG  and retry"
  "$ADB" -s "$SERIAL" shell am start -n "$PKG/.MainActivity" >/dev/null 2>&1 || true
  echo "Installed on $SERIAL and started."
fi

