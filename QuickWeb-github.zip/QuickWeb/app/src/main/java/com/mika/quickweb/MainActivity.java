package com.mika.quickweb;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * QuickWeb – a fast, minimal browser for Galaxy Watch 7 (Wear OS).
 * Round-display friendly, high contrast, no external libraries.
 */
public class MainActivity extends Activity {

    private static final String PREFS = "quickweb";
    private static final String KEY_BOOKMARKS = "bookmarks";
    private static final String KEY_DESKTOP = "desktop_mode";
    private static final String KEY_LAST_URL = "last_url";
    private static final String KEY_TEXT_ZOOM = "text_zoom";

    private static final String UA_MOBILE =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
    private static final String UA_DESKTOP =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    // Built-in quick links (title, url)
    private static final String[][] QUICK = {
            {"Google",     "https://www.google.com"},
            {"DuckDuckGo", "https://duckduckgo.com"},
            {"Wikipedia",  "https://en.wikipedia.org"},
            {"YouTube",    "https://m.youtube.com"},
            {"Reddit",     "https://www.reddit.com"},
            {"X",          "https://x.com"},
            {"Maps",       "https://maps.google.com"},
            {"News",       "https://news.google.com"},
    };

    private SharedPreferences prefs;
    private FrameLayout root;
    private WebView web;
    private ProgressBar progress;
    private LinearLayout toolbar;
    private LinearLayout homeView;
    private TextView urlLabel;
    private Button btnBack, btnFwd, btnReload, btnHome, btnBookmark, btnZoomOut, btnZoomIn, btnMore;
    private boolean showingHome = true;
    private boolean desktopMode;
    private String currentUrl = "";
    private int textZoomPercent = 100;   // 50–300
    private float pageScale = 1f;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            initUi();
        } catch (Throwable t) {
            // Show the error on screen instead of crashing (e.g. no WebView on this watch)
            Log.e("QuickWeb", "Startup failed", t);
            showFatal(t);
        }
    }

    private void initUi() {
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        desktopMode = prefs.getBoolean(KEY_DESKTOP, false);
        textZoomPercent = prefs.getInt(KEY_TEXT_ZOOM, 100);
        if (textZoomPercent < 50 || textZoomPercent > 300) textZoomPercent = 100;

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0A0E17"));
        setContentView(root);

        buildHomeView();
        buildBrowserView();

        root.addView(homeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(progress, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        root.addView(toolbar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        web.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        toolbar.setVisibility(View.GONE);

        handleIntent(getIntent());
    }

    private void showFatal(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        String[] lines = sw.toString().split("\n");
        StringBuilder sb = new StringBuilder("QuickWeb could not start\n\n");
        for (int i = 0; i < lines.length && i < 12; i++) sb.append(lines[i]).append('\n');
        if (String.valueOf(t).contains("WebView")) {
            sb.append("\nThis watch has no usable WebView.");
        }
        TextView tv = new TextView(this);
        tv.setText(sb.toString());
        tv.setTextColor(Color.parseColor("#F87171"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tv.setPadding(dp(24), dp(32), dp(24), dp(32));
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0A0E17"));
        sv.addView(tv);
        setContentView(sv);
        web = null;
        showingHome = true;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri data = intent.getData();
        if (Intent.ACTION_VIEW.equals(action) && data != null) {
            String url = data.toString();
            if (url.startsWith("http://") || url.startsWith("https://")) {
                openUrl(url);
                return;
            }
        }
        // Default: show home (or restore last page if we want, but home is safer for battery)
        showHome();
    }

    // ------------------------------------------------------------------ UI builders

    private void buildHomeView() {
        homeView = new LinearLayout(this);
        homeView.setOrientation(LinearLayout.VERTICAL);
        homeView.setGravity(Gravity.CENTER_HORIZONTAL);
        homeView.setPadding(dp(12), dp(18), dp(12), dp(12));
        homeView.setBackgroundColor(Color.parseColor("#0A0E17"));

        TextView title = new TextView(this);
        title.setText("QuickWeb");
        title.setTextColor(Color.parseColor("#22D3EE"));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        homeView.addView(title, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(8)));

        // Search / URL bar
        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);

        EditText urlInput = new EditText(this);
        urlInput.setHint("Search or URL");
        urlInput.setHintTextColor(Color.parseColor("#64748B"));
        urlInput.setTextColor(Color.parseColor("#F1F5F9"));
        urlInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        urlInput.setSingleLine(true);
        urlInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setBackground(roundedBg("#151B2B", 12));
        urlInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                String q = urlInput.getText().toString().trim();
                if (!q.isEmpty()) {
                    hideKeyboard(urlInput);
                    openUrl(resolveQuery(q));
                }
                return true;
            }
            return false;
        });

        Button goBtn = pillButton("Go", "#22D3EE", "#0A0E17");
        goBtn.setOnClickListener(v -> {
            String q = urlInput.getText().toString().trim();
            if (!q.isEmpty()) {
                hideKeyboard(urlInput);
                openUrl(resolveQuery(q));
            }
        });

        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        inputLp.rightMargin = dp(6);
        searchRow.addView(urlInput, inputLp);
        searchRow.addView(goBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        homeView.addView(searchRow, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, dp(12)));

        // Scrollable list of quick links + bookmarks
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView sectionQuick = sectionLabel("Quick links");
        list.addView(sectionQuick);

        for (String[] item : QUICK) {
            list.addView(linkButton(item[0], item[1]));
        }

        TextView sectionBm = sectionLabel("Bookmarks");
        list.addView(sectionBm);

        List<Bookmark> bms = loadBookmarks();
        if (bms.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(getString(R.string.empty_bookmarks));
            empty.setTextColor(Color.parseColor("#64748B"));
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(8), dp(8), dp(8), dp(8));
            list.addView(empty);
        } else {
            for (Bookmark b : bms) {
                View row = bookmarkRow(b);
                list.addView(row);
            }
        }

        // Clear cache button
        Button clear = pillButton("Clear cache", "#334155", "#F1F5F9");
        clear.setOnClickListener(v -> {
            if (web != null) {
                web.clearCache(true);
                web.clearHistory();
                CookieManager.getInstance().removeAllCookies(null);
                Toast.makeText(this, R.string.cache_cleared, Toast.LENGTH_SHORT).show();
            }
        });
        list.addView(clear, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, dp(16), 0, dp(8)));

        scroll.addView(list);
        homeView.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void buildBrowserView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0A0E17"));
        configureWebView(web);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        progress.getProgressDrawable().setColorFilter(
                Color.parseColor("#22D3EE"), android.graphics.PorterDuff.Mode.SRC_IN);

        // Bottom toolbar
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setBackgroundColor(Color.parseColor("#CC0A0E17"));
        toolbar.setPadding(dp(4), dp(4), dp(4), dp(6));

        urlLabel = new TextView(this);
        urlLabel.setTextColor(Color.parseColor("#94A3B8"));
        urlLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        urlLabel.setSingleLine(true);
        urlLabel.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        urlLabel.setGravity(Gravity.CENTER);
        urlLabel.setPadding(dp(8), dp(2), dp(8), dp(2));
        urlLabel.setOnClickListener(v -> showUrlDialog());
        toolbar.addView(urlLabel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);

        btnBack = makeToolBtn("◀", v -> { if (web.canGoBack()) web.goBack(); });
        btnFwd = makeToolBtn("▶", v -> { if (web.canGoForward()) web.goForward(); });
        btnReload = makeToolBtn("↻", v -> {
            if (web.getProgress() < 100) web.stopLoading();
            else web.reload();
        });
        btnHome = makeToolBtn("⌂", v -> showHome());
        btnBookmark = makeToolBtn("★", v -> toggleBookmark());
        btnZoomOut = makeToolBtn("−", v -> zoomOut());
        btnZoomIn = makeToolBtn("+", v -> zoomIn());
        btnMore = makeToolBtn("⋮", v -> showMoreMenu());

        buttons.addView(btnBack);
        buttons.addView(btnFwd);
        buttons.addView(btnReload);
        buttons.addView(btnHome);
        buttons.addView(btnBookmark);
        buttons.addView(btnZoomOut);
        buttons.addView(btnZoomIn);
        buttons.addView(btnMore);
        hsv.addView(buttons);
        toolbar.addView(hsv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Long-press on WebView adds bookmark
        web.setOnLongClickListener(v -> {
            toggleBookmark();
            return true;
        });
    }

    private void configureWebView(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);   // no system +/- overlay; we have our own buttons
        s.setSupportZoom(true);
        s.setTextZoom(textZoomPercent);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(desktopMode ? UA_DESKTOP : UA_MOBILE);
        if (Build.VERSION.SDK_INT >= 26) {
            s.setSafeBrowsingEnabled(true);
        }

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if (scheme == null) return false;
                if (scheme.equals("http") || scheme.equals("https")) {
                    return false; // let WebView handle
                }
                // tel:, mailto:, etc. – try to open externally
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                currentUrl = url;
                urlLabel.setText(prettyUrl(url));
                progress.setVisibility(View.VISIBLE);
                progress.setProgress(0);
                btnReload.setText("■");
                updateNavButtons();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                currentUrl = url;
                urlLabel.setText(prettyUrl(url));
                progress.setVisibility(View.GONE);
                btnReload.setText("↻");
                updateNavButtons();
                prefs.edit().putString(KEY_LAST_URL, url).apply();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    progress.setVisibility(View.GONE);
                    btnReload.setText("↻");
                    String msg = "Error " + error.getErrorCode() + ": " + error.getDescription();
                    showErrorOverlay(msg);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress >= 100) {
                    progress.setVisibility(View.GONE);
                } else {
                    progress.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                // keep for potential future use
            }
        });
    }

    // ------------------------------------------------------------------ Navigation

    private void openUrl(String url) {
        if (!isOnline()) {
            Toast.makeText(this, R.string.no_network, Toast.LENGTH_SHORT).show();
            // still try – WebView will show its own error
        }
        showingHome = false;
        homeView.setVisibility(View.GONE);
        web.setVisibility(View.VISIBLE);
        toolbar.setVisibility(View.VISIBLE);
        progress.setVisibility(View.VISIBLE);
        currentUrl = url;
        urlLabel.setText(prettyUrl(url));
        web.loadUrl(url);
    }

    private void showHome() {
        showingHome = true;
        web.setVisibility(View.GONE);
        toolbar.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        homeView.setVisibility(View.VISIBLE);
        // Rebuild home so bookmarks stay up to date
        root.removeView(homeView);
        buildHomeView();
        root.addView(homeView, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void updateNavButtons() {
        btnBack.setEnabled(web.canGoBack());
        btnFwd.setEnabled(web.canGoForward());
        btnBack.setAlpha(web.canGoBack() ? 1f : 0.35f);
        btnFwd.setAlpha(web.canGoForward() ? 1f : 0.35f);
    }

    private String resolveQuery(String q) {
        q = q.trim();
        if (q.startsWith("http://") || q.startsWith("https://")) return q;
        if (q.contains(".") && !q.contains(" ")) {
            // looks like a domain
            return "https://" + q;
        }
        // search
        return "https://duckduckgo.com/?q=" + Uri.encode(q);
    }

    private String prettyUrl(String url) {
        if (url == null) return "";
        try {
            Uri u = Uri.parse(url);
            String host = u.getHost();
            if (host == null) return url;
            if (host.startsWith("www.")) host = host.substring(4);
            String path = u.getPath();
            if (path == null || path.equals("/")) return host;
            if (path.length() > 18) path = path.substring(0, 16) + "…";
            return host + path;
        } catch (Exception e) {
            return url;
        }
    }

    // ------------------------------------------------------------------ Bookmarks

    private static class Bookmark {
        final String title;
        final String url;
        Bookmark(String t, String u) { title = t; url = u; }
    }

    private List<Bookmark> loadBookmarks() {
        List<Bookmark> list = new ArrayList<>();
        String raw = prefs.getString(KEY_BOOKMARKS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new Bookmark(o.optString("t", "Link"), o.optString("u", "")));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    private void saveBookmarks(List<Bookmark> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Bookmark b : list) {
                JSONObject o = new JSONObject();
                o.put("t", b.title);
                o.put("u", b.url);
                arr.put(o);
            }
            prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void toggleBookmark() {
        if (currentUrl == null || currentUrl.isEmpty() || showingHome) return;
        List<Bookmark> list = loadBookmarks();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).url.equals(currentUrl)) {
                list.remove(i);
                saveBookmarks(list);
                Toast.makeText(this, "Bookmark removed", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        String title = web.getTitle();
        if (title == null || title.isEmpty()) title = prettyUrl(currentUrl);
        if (title.length() > 40) title = title.substring(0, 38) + "…";
        list.add(0, new Bookmark(title, currentUrl));
        // keep max 30
        while (list.size() > 30) list.remove(list.size() - 1);
        saveBookmarks(list);
        Toast.makeText(this, R.string.bookmark_added, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ Dialogs / menus

    private void showUrlDialog() {
        final EditText input = new EditText(this);
        input.setText(currentUrl);
        input.setSelectAllOnFocus(true);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Open URL")
                .setView(input)
                .setPositiveButton("Go", (dialog, which) -> {
                    String q = input.getText().toString().trim();
                    if (!q.isEmpty()) openUrl(resolveQuery(q));
                })
                .setNegativeButton("Cancel", null)
                .create();
        d.show();
        input.requestFocus();
        mainHandler.postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }, 200);
    }

    // ------------------------------------------------------------------ Zoom

    /** Page zoom (pinch + buttons). Uses WebView's built-in zoom engine. */
    private void zoomIn() {
        if (web == null || showingHome) return;
        boolean ok = web.zoomIn();
        if (!ok) {
            // Fallback: increase text zoom when page zoom is already at max
            adjustTextZoom(+15);
        } else {
            pageScale = Math.min(pageScale * 1.25f, 5f);
            showZoomToast();
        }
    }

    private void zoomOut() {
        if (web == null || showingHome) return;
        boolean ok = web.zoomOut();
        if (!ok) {
            adjustTextZoom(-15);
        } else {
            pageScale = Math.max(pageScale / 1.25f, 0.25f);
            showZoomToast();
        }
    }

    private void resetZoom() {
        if (web == null) return;
        textZoomPercent = 100;
        pageScale = 1f;
        web.getSettings().setTextZoom(100);
        prefs.edit().putInt(KEY_TEXT_ZOOM, 100).apply();
        web.getSettings().setLoadWithOverviewMode(true);
        web.getSettings().setUseWideViewPort(true);
        // Best-effort visual reset (works on most WebView versions)
        web.evaluateJavascript(
                "document.body.style.zoom='1'; document.documentElement.style.zoom='1';",
                null);
        Toast.makeText(this, "Zoom reset (100%)", Toast.LENGTH_SHORT).show();
    }

    private void adjustTextZoom(int delta) {
        textZoomPercent = Math.max(50, Math.min(300, textZoomPercent + delta));
        web.getSettings().setTextZoom(textZoomPercent);
        prefs.edit().putInt(KEY_TEXT_ZOOM, textZoomPercent).apply();
        Toast.makeText(this, "Text " + textZoomPercent + "%", Toast.LENGTH_SHORT).show();
    }

    private void showZoomToast() {
        // Prefer live scale when available
        try {
            float s = web.getScale();
            if (s > 0.05f) pageScale = s;
        } catch (Exception ignored) {
        }
        int pct = Math.round(pageScale * 100);
        Toast.makeText(this, "Zoom " + pct + "%", Toast.LENGTH_SHORT).show();
    }

    private void showMoreMenu() {
        String[] items = {
                desktopMode ? "Switch to mobile site" : "Switch to desktop site",
                "Zoom in (+)",
                "Zoom out (−)",
                "Text larger",
                "Text smaller",
                "Reset zoom",
                "Add / remove bookmark",
                "Clear cache",
                "Reload"
        };
        new AlertDialog.Builder(this)
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            desktopMode = !desktopMode;
                            prefs.edit().putBoolean(KEY_DESKTOP, desktopMode).apply();
                            web.getSettings().setUserAgentString(desktopMode ? UA_DESKTOP : UA_MOBILE);
                            web.reload();
                            Toast.makeText(this, desktopMode ? "Desktop mode" : "Mobile mode", Toast.LENGTH_SHORT).show();
                            break;
                        case 1:
                            zoomIn();
                            break;
                        case 2:
                            zoomOut();
                            break;
                        case 3:
                            adjustTextZoom(+20);
                            break;
                        case 4:
                            adjustTextZoom(-20);
                            break;
                        case 5:
                            resetZoom();
                            break;
                        case 6:
                            toggleBookmark();
                            break;
                        case 7:
                            web.clearCache(true);
                            Toast.makeText(this, R.string.cache_cleared, Toast.LENGTH_SHORT).show();
                            break;
                        case 8:
                            web.reload();
                            break;
                    }
                })
                .show();
    }

    private void showErrorOverlay(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ Helpers – UI widgets

    private TextView sectionLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.parseColor("#64748B"));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(4), dp(12), dp(4), dp(4));
        return t;
    }

    private View linkButton(String title, String url) {
        Button b = pillButton(title, "#151B2B", "#F1F5F9");
        b.setOnClickListener(v -> openUrl(url));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private View bookmarkRow(Bookmark b) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(roundedBg("#151B2B", 10));
        row.setPadding(dp(10), dp(8), dp(6), dp(8));

        TextView t = new TextView(this);
        t.setText(b.title);
        t.setTextColor(Color.parseColor("#F1F5F9"));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(t, tLp);

        TextView del = new TextView(this);
        del.setText("✕");
        del.setTextColor(Color.parseColor("#F87171"));
        del.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        del.setPadding(dp(10), dp(4), dp(6), dp(4));
        del.setOnClickListener(v -> {
            List<Bookmark> list = loadBookmarks();
            list.removeIf(x -> x.url.equals(b.url));
            saveBookmarks(list);
            showHome(); // refresh
        });
        row.addView(del);

        row.setOnClickListener(v -> openUrl(b.url));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(6);
        row.setLayoutParams(lp);
        return row;
    }

    private Button pillButton(String text, String bgHex, String fgHex) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.parseColor(fgHex));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setAllCaps(false);
        b.setBackground(roundedBg(bgHex, 12));
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        b.setMinHeight(dp(40));
        return b;
    }

    private Button makeToolBtn(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.parseColor("#F1F5F9"));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setAllCaps(false);
        b.setBackground(roundedBg("#1E293B", 10));
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        b.setMinWidth(dp(42));
        b.setMinHeight(dp(38));
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private GradientDrawable roundedBg(String colorHex, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(colorHex));
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        Network n = cm.getActiveNetwork();
        if (n == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
        return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    @Override
    public void onBackPressed() {
        if (!showingHome && web.canGoBack()) {
            web.goBack();
        } else if (!showingHome) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.stopLoading();
            web.destroy();
        }
        super.onDestroy();
    }
}
