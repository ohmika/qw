#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "[1/5] Checking Java ..."
if ! JAVA_HOME="$(/usr/libexec/java_home -v 17 2>/dev/null)"; then
  echo "FAILED: Java 17 not found."
  echo "Fix: Install: brew install --cask temurin@17"
  exit 1
fi
export JAVA_HOME
echo "Java: $JAVA_HOME"
"$JAVA_HOME/bin/java" -version

echo "[2/5] Checking Android SDK ..."
if [ -z "${ANDROID_HOME:-}" ]; then
  ANDROID_HOME="$HOME/Library/Android/sdk"
fi
if [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  ANDROID_SDK_ROOT="$ANDROID_HOME"
fi
export ANDROID_HOME
export ANDROID_SDK_ROOT
if [ ! -d "$ANDROID_HOME" ]; then
  echo "FAILED: Android SDK not found at $ANDROID_HOME"
  echo "Fix: Install cmdline-tools in $HOME/Library/Android/sdk"
  exit 1
fi
echo "Android SDK: $ANDROID_HOME"

echo "[3/5] Writing local.properties ..."
printf "sdk.dir=%s\n" "$ANDROID_HOME" > local.properties
cat local.properties

echo "[4/5] Checking SDK packages (platforms;android-35, build-tools;34.0.0) ..."
SDKMANAGER=""
if [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
elif [ -x "$ANDROID_HOME/cmdline-tools/bin/sdkmanager" ]; then
  SDKMANAGER="$ANDROID_HOME/cmdline-tools/bin/sdkmanager"
else
  FOUND="$(find "$ANDROID_HOME/cmdline-tools" -name sdkmanager -type f 2>/dev/null | head -n 1 || true)"
  if [ -n "$FOUND" ]; then
    SDKMANAGER="$FOUND"
  fi
fi

if [ ! -d "$ANDROID_HOME/platforms/android-35" ] || [ ! -d "$ANDROID_HOME/build-tools/34.0.0" ]; then
  if [ -z "$SDKMANAGER" ]; then
    echo "FAILED: SDK packages missing and sdkmanager not found."
    echo "Fix: Install cmdline-tools in Android SDK, then run this script again."
    exit 1
  fi
  echo "Installing missing SDK packages..."
  yes | "$SDKMANAGER" --licenses || true
  "$SDKMANAGER" "platforms;android-35" "build-tools;34.0.0"
else
  echo "SDK packages already installed."
fi

echo "[5/5] Building APK ..."
chmod +x ./gradlew 2>/dev/null || true
GRADLE_CMD=""
if [ -f "./gradlew" ] && [ -f "gradle/wrapper/gradle-wrapper.jar" ]; then
  GRADLE_CMD="sh ./gradlew"
  echo "Using Gradle wrapper: ./gradlew"
else
  echo "Gradle wrapper not found, looking for Gradle in ~/gradle ..."
  FOUND_GRADLE="$(find "$HOME/gradle" -name gradle -type f 2>/dev/null | head -n 1 || true)"
  if [ -z "$FOUND_GRADLE" ]; then
    echo "FAILED: No Gradle found."
    echo "Fix: Install Gradle 8.10.2 in ~/gradle or add gradle wrapper files."
    exit 1
  fi
  GRADLE_CMD="$FOUND_GRADLE"
  echo "Using Gradle binary: $GRADLE_CMD"
  # Try to generate wrapper for next time, do not fail if it fails
  $GRADLE_CMD wrapper --gradle-version 8.10.2 || true
  if [ -f "./gradlew" ]; then
    GRADLE_CMD="sh ./gradlew"
  fi
fi

$GRADLE_CMD assembleDebug --no-daemon --console=plain

APK_SRC="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK_SRC" ]; then
  echo "FAILED: APK not found at $APK_SRC"
  exit 1
fi

cp "$APK_SRC" "./QuickWeb.apk"
APK_SIZE="$(stat -f %z "./QuickWeb.apk")"
echo ""
echo "BUILD OK"
echo "APK: $PWD/QuickWeb.apk"
echo "Size: $APK_SIZE bytes"
echo ""
echo "Install on watch over Wi-Fi:"
echo "  1. Watch: Settings > About watch > Software > tap Build number 7x"
echo "  2. Watch: Settings > Developer options > ADB debugging ON, Wireless debugging ON"
echo "  3. Mac: adb pair <ip>:<pairing-port>"
echo "  4. Mac: adb connect <ip>:<connect-port>"
echo "  5. Mac: adb install -r QuickWeb.apk"
echo "Or run: ./build.sh install"

if [ "${1:-}" = "install" ]; then
  echo ""
  echo "Installing on connected device ..."
  if ! command -v adb >/dev/null 2>&1; then
    echo "FAILED: adb not found. Fix: brew install --cask android-platform-tools"
    exit 1
  fi
  adb install -r "./QuickWeb.apk"
  echo "Install done."
fi
