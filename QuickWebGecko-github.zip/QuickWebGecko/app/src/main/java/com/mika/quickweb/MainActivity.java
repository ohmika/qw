package com.mika.quickweb;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * QuickWeb for Wear OS. The Galaxy Watch 7 has no system WebView, so pages are
 * rendered with GeckoView (the Firefox engine).
 */
public class MainActivity extends Activity {

    private static final String PREFS = "quickweb";
    private static final String KEY_BOOKMARKS = "bookmarks";
    private static final String KEY_DESKTOP = "desktop";
    private static final String KEY_LAST_URL = "last_url";
    private static final String KEY_TEXT_ZOOM = "text_zoom";

    private static final int BG = 0xFF0A0E17, CARD = 0xFF151B2B, FIELD = 0xFF1E293B,
            ACCENT = 0xFF22D3EE, LINE = 0xFF334155, MUTED = 0xFF64748B, SUB = 0xFF94A3B8,
            TEXT = 0xFFF1F5F9, RED = 0xFFF87171;

    private static final String[][] QUICK = {
            {"Google", "https://www.google.com"}, {"DuckDuckGo", "https://duckduckgo.com"},
            {"Wikipedia", "https://en.wikipedia.org"}, {"YouTube", "https://m.youtube.com"},
            {"Maps", "https://maps.google.com"}, {"News", "https://news.google.com"},
            {"Reddit", "https://www.reddit.com"}, {"X", "https://x.com"}};

    private SharedPreferences prefs;
    private float d;

    private FrameLayout root;
    private ScrollView homeView;
    private LinearLayout listContainer;
    private EditText urlInput;
    private LinearLayout webScreen;
    private FrameLayout geckoContainer;
    private TextView urlLabel;
    private ProgressBar progress;
    private Button btnBack, btnFwd, btnBookmark;

    private GeckoRuntime runtime;
    private GeckoSession session;
    private GeckoView geckoView;
    private boolean canBack, canFwd, desktop;
    private int textZoom;
    private String currentUrl, currentTitle;
    private final List<String[]> bookmarks = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        d = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        desktop = prefs.getBoolean(KEY_DESKTOP, false);
        textZoom = Math.max(50, Math.min(300, prefs.getInt(KEY_TEXT_ZOOM, 100)));
        loadBookmarks();

        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        buildHome();
        buildWeb();
        setContentView(root);
        showHome();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            openUrl(intent.getData().toString());
        }
    }

    // ---------- UI helpers ----------

    private int dp(int v) {
        return Math.round(v * d);
    }

    private GradientDrawable roundedBg(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private Button pill(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(fg);
        b.setMaxLines(1);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setBackground(roundedBg(bg, 18));
        return b;
    }

    private TextView sectionLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(11);
        t.setTextColor(MUTED);
        t.setPadding(0, dp(14), 0, dp(4));
        return t;
    }

    // ---------- Home screen ----------

    private void buildHome() {
        homeView = new ScrollView(this);
        homeView.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(30), dp(38), dp(30), dp(56));
        homeView.addView(content);

        TextView title = new TextView(this);
        title.setText("QuickWeb");
        title.setTextColor(ACCENT);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        content.addView(title);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams srp = new LinearLayout.LayoutParams(-1, -2);
        srp.topMargin = dp(10);
        content.addView(searchRow, srp);

        urlInput = new EditText(this);
        urlInput.setHint("Search or URL");
        urlInput.setHintTextColor(MUTED);
        urlInput.setTextColor(TEXT);
        urlInput.setTextSize(14);
        urlInput.setMaxLines(1);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlInput.setBackground(roundedBg(FIELD, 18));
        urlInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        searchRow.addView(urlInput, new LinearLayout.LayoutParams(0, dp(44), 1f));

        Button go = pill("Go", ACCENT, BG);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-2, dp(44));
        gp.leftMargin = dp(6);
        searchRow.addView(go, gp);
        go.setOnClickListener(v -> submitInput());
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            submitInput();
            return true;
        });

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(listContainer, new LinearLayout.LayoutParams(-1, -2));

        root.addView(homeView, new FrameLayout.LayoutParams(-1, -1));
    }

    private void submitInput() {
        String raw = urlInput.getText().toString().trim();
        if (raw.isEmpty()) return;
        openUrl(resolveQuery(raw));
    }

    private String resolveQuery(String raw) {
        String s = raw.trim();
        if (s.matches("(?i)^https?://.*")) return s;
        if (!s.contains(" ") && (s.contains(".") || s.startsWith("localhost"))) return "https://" + s;
        try {
            return "https://duckduckgo.com/?q=" + URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return "https://duckduckgo.com";
        }
    }

    private void refreshHome() {
        listContainer.removeAllViews();

        String last = prefs.getString(KEY_LAST_URL, null);
        if (last != null) {
            Button cont = pill("Continue: " + prettyUrl(last), FIELD, ACCENT);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.topMargin = dp(10);
            listContainer.addView(cont, cp);
            final String lastUrl = last;
            cont.setOnClickListener(v -> openUrl(lastUrl));
        }

        listContainer.addView(sectionLabel("Quick links"));
        for (int i = 0; i < QUICK.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = i; j < Math.min(i + 2, QUICK.length); j++) {
                final String[] q = QUICK[j];
                Button b = pill(q[0], CARD, TEXT);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                lp.setMargins(dp(2), dp(2), dp(2), dp(2));
                row.addView(b, lp);
                b.setOnClickListener(v -> openUrl(q[1]));
            }
            listContainer.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }

        listContainer.addView(sectionLabel("Bookmarks"));
        if (bookmarks.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No bookmarks yet. Open a page and tap the star.");
            empty.setTextColor(MUTED);
            empty.setTextSize(12);
            listContainer.addView(empty);
        }
        for (final String[] bm : new ArrayList<>(bookmarks)) {
            Button b = pill(bm[0], CARD, TEXT);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(2), 0, dp(2));
            listContainer.addView(b, lp);
            b.setOnClickListener(v -> openUrl(bm[1]));
            b.setOnLongClickListener(v -> {
                removeBookmark(bm[1]);
                Toast.makeText(this, "Bookmark removed", Toast.LENGTH_SHORT).show();
                refreshHome();
                return true;
            });
        }
    }

    // ---------- Web screen ----------

    private void buildWeb() {
        webScreen = new LinearLayout(this);
        webScreen.setOrientation(LinearLayout.VERTICAL);
        webScreen.setBackgroundColor(BG);

        urlLabel = new TextView(this);
        urlLabel.setTextSize(11);
        urlLabel.setTextColor(SUB);
        urlLabel.setGravity(Gravity.CENTER);
        urlLabel.setMaxLines(1);
        urlLabel.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(46), dp(10), dp(46), dp(3));
        webScreen.addView(urlLabel, lp);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(ACCENT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(LINE));
        webScreen.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        geckoContainer = new FrameLayout(this);
        webScreen.addView(geckoContainer, new LinearLayout.LayoutParams(-1, 0, 1f));

        HorizontalScrollView bar = new HorizontalScrollView(this);
        bar.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        bar.addView(row);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(44));
        bp.setMargins(dp(34), dp(4), dp(34), dp(12));
        webScreen.addView(bar, bp);

        btnBack = tool(row, "\u2039", v -> goBackOrHome());
        btnFwd = tool(row, "\u203A", v -> {
            if (session != null && canFwd) session.goForward();
        });
        tool(row, "Home", v -> {
            showHome();
            refreshHome();
        });
        tool(row, "Reload", v -> {
            if (session != null) session.reload();
        });
        btnBookmark = tool(row, "\u2606", v -> toggleBookmark());
        tool(row, "A\u2212", v -> adjustTextZoom(-20));
        tool(row, "A+", v -> adjustTextZoom(20));
        tool(row, "More", v -> showMore());

        webScreen.setVisibility(View.GONE);
        root.addView(webScreen, new FrameLayout.LayoutParams(-1, -1));
        updateNavButtons();
    }

    private Button tool(LinearLayout row, String text, View.OnClickListener l) {
        Button b = pill(text, CARD, TEXT);
        b.setMinWidth(dp(44));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -1);
        lp.setMargins(dp(3), 0, dp(3), 0);
        row.addView(b, lp);
        b.setOnClickListener(l);
        return b;
    }

    private void updateNavButtons() {
        if (btnBack != null) btnBack.setAlpha(canBack ? 1f : 0.4f);
        if (btnFwd != null) btnFwd.setAlpha(canFwd ? 1f : 0.4f);
        if (btnBookmark != null) btnBookmark.setText(isBookmarked(currentUrl) ? "\u2605" : "\u2606");
    }

    private void showHome() {
        homeView.setVisibility(View.VISIBLE);
        webScreen.setVisibility(View.GONE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        refreshHome();
    }

    private void showWeb() {
        homeView.setVisibility(View.GONE);
        webScreen.setVisibility(View.VISIBLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (geckoView != null) geckoView.requestFocus();
    }

    private void goBackOrHome() {
        if (session != null && canBack) session.goBack();
        else showHome();
    }

    private void showMore() {
        final CharSequence[] items = {
                isBookmarked(currentUrl) ? "Remove bookmark" : "Add bookmark",
                desktop ? "Switch to mobile site" : "Switch to desktop site",
                "Clear cache", "Text larger", "Text smaller", "Reset zoom", "Cancel"};
        new AlertDialog.Builder(this).setTitle("QuickWeb").setItems(items, (dialog, which) -> {
            switch (which) {
                case 0: toggleBookmark(); break;
                case 1: toggleDesktop(); break;
                case 2: clearCache(); break;
                case 3: adjustTextZoom(20); break;
                case 4: adjustTextZoom(-20); break;
                case 5: adjustTextZoom(100 - textZoom); break;
                default: break;
            }
        }).show();
    }

    // ---------- Browser engine ----------

    private boolean ensureBrowser() {
        if (geckoView != null) return true;
        try {
            runtime = GeckoRuntime.getDefault(getApplicationContext());
            runtime.getSettings().setAutomaticFontSizeAdjustment(false);
            runtime.getSettings().setFontSizeFactor(textZoom / 100f);

            session = new GeckoSession();
            applyDesktopSettings();
            session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
                @Override
                public void onPageStart(GeckoSession s, String url) {
                    currentUrl = url;
                    currentTitle = null;
                    prefs.edit().putString(KEY_LAST_URL, url).apply();
                    urlLabel.setText(prettyUrl(url));
                    progress.setVisibility(View.VISIBLE);
                    progress.setProgress(5);
                    updateNavButtons();
                }

                @Override
                public void onProgressChange(GeckoSession s, int p) {
                    progress.setProgress(p);
                    progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
                }

                @Override
                public void onPageStop(GeckoSession s, boolean success) {
                    progress.setVisibility(View.INVISIBLE);
                    if (!success) Toast.makeText(MainActivity.this, "Could not load page", Toast.LENGTH_SHORT).show();
                    updateNavButtons();
                }
            });
            session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
                @Override
                public void onCanGoBack(GeckoSession s, boolean can) {
                    canBack = can;
                    updateNavButtons();
                }

                @Override
                public void onCanGoForward(GeckoSession s, boolean can) {
                    canFwd = can;
                    updateNavButtons();
                }
            });
            session.setContentDelegate(new GeckoSession.ContentDelegate() {
                @Override
                public void onTitleChange(GeckoSession s, String title) {
                    currentTitle = title;
                }

                @Override
                public void onCrash(GeckoSession s) {
                    recoverSession();
                }

                @Override
                public void onKill(GeckoSession s) {
                    recoverSession();
                }
            });
            session.open(runtime);

            geckoView = new GeckoView(this);
            geckoView.setSession(session);
            geckoContainer.addView(geckoView, new FrameLayout.LayoutParams(-1, -1));
            return true;
        } catch (Throwable t) {
            TextView err = new TextView(this);
            err.setText("QuickWeb could not start\n\n" + t);
            err.setTextColor(RED);
            err.setTextSize(12);
            err.setPadding(dp(34), dp(40), dp(34), dp(40));
            ScrollView sv = new ScrollView(this);
            sv.setBackgroundColor(BG);
            sv.addView(err);
            setContentView(sv);
            return false;
        }
    }

    private void recoverSession() {
        if (session == null || runtime == null) return;
        Toast.makeText(this, "Page crashed, reloading", Toast.LENGTH_SHORT).show();
        session.open(runtime);
        if (currentUrl != null) session.loadUri(currentUrl);
    }

    private void applyDesktopSettings() {
        if (session == null) return;
        session.getSettings().setUserAgentMode(desktop
                ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP : GeckoSessionSettings.USER_AGENT_MODE_MOBILE);
        session.getSettings().setViewportMode(desktop
                ? GeckoSessionSettings.VIEWPORT_MODE_DESKTOP : GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
    }

    private void toggleDesktop() {
        desktop = !desktop;
        prefs.edit().putBoolean(KEY_DESKTOP, desktop).apply();
        applyDesktopSettings();
        if (session != null) session.reload();
        Toast.makeText(this, desktop ? "Desktop mode" : "Mobile mode", Toast.LENGTH_SHORT).show();
    }

    private void adjustTextZoom(int delta) {
        textZoom = Math.max(50, Math.min(300, textZoom + delta));
        prefs.edit().putInt(KEY_TEXT_ZOOM, textZoom).apply();
        if (runtime != null) runtime.getSettings().setFontSizeFactor(textZoom / 100f);
        Toast.makeText(this, "Text " + textZoom + "%", Toast.LENGTH_SHORT).show();
    }

    // Done through reflection so a different GeckoView version cannot break the build
    private void clearCache() {
        try {
            if (runtime == null && !ensureBrowser()) return;
            Class<?> flags = Class.forName("org.mozilla.geckoview.StorageController$ClearFlags");
            long all = flags.getField("ALL_CACHES").getLong(null);
            Object sc = runtime.getStorageController();
            sc.getClass().getMethod("clearData", long.class).invoke(sc, all);
            Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(this, "Could not clear cache", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        Network n = cm.getActiveNetwork();
        NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
        return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void openUrl(String url) {
        if (!isOnline()) {
            Toast.makeText(this, "No network", Toast.LENGTH_LONG).show();
            return;
        }
        if (!ensureBrowser()) return;
        currentUrl = url;
        currentTitle = null;
        prefs.edit().putString(KEY_LAST_URL, url).apply();
        urlLabel.setText(prettyUrl(url));
        updateNavButtons();
        showWeb();
        session.loadUri(url);
    }

    private static String prettyUrl(String url) {
        if (url == null) return "";
        String s = url.replaceFirst("^https?://", "").replaceFirst("^www\\.", "");
        return s.endsWith("/") ? s.substring(0, s.length() - 1) : s;
    }

    // ---------- Bookmarks ----------

    private void loadBookmarks() {
        bookmarks.clear();
        try {
            JSONArray arr = new JSONArray(prefs.getString(KEY_BOOKMARKS, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                bookmarks.add(new String[]{o.optString("title"), o.optString("url")});
            }
        } catch (Exception ignored) {
        }
    }

    private void saveBookmarks() {
        JSONArray arr = new JSONArray();
        try {
            for (String[] b : bookmarks) {
                arr.put(new JSONObject().put("title", b[0]).put("url", b[1]));
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply();
    }

    private boolean isBookmarked(String url) {
        if (url == null) return false;
        for (String[] b : bookmarks) if (b[1].equals(url)) return true;
        return false;
    }

    private void removeBookmark(String url) {
        for (int i = bookmarks.size() - 1; i >= 0; i--) if (bookmarks.get(i)[1].equals(url)) bookmarks.remove(i);
        saveBookmarks();
    }

    private void toggleBookmark() {
        if (currentUrl == null) return;
        if (isBookmarked(currentUrl)) {
            removeBookmark(currentUrl);
            Toast.makeText(this, "Bookmark removed", Toast.LENGTH_SHORT).show();
        } else {
            String title = currentTitle != null && !currentTitle.trim().isEmpty()
                    ? currentTitle.trim() : prettyUrl(currentUrl);
            bookmarks.add(0, new String[]{title, currentUrl});
            saveBookmarks();
            Toast.makeText(this, "Bookmark added", Toast.LENGTH_SHORT).show();
        }
        updateNavButtons();
    }

    // ---------- Input ----------

    // Crown scrolls the page; the Gecko call goes through reflection
    @Override
    public boolean onGenericMotionEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_SCROLL
                && ev.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER)) {
            float delta = -ev.getAxisValue(MotionEvent.AXIS_SCROLL)
                    * ViewConfiguration.get(this).getScaledVerticalScrollFactor();
            if (webScreen.getVisibility() == View.VISIBLE && session != null) {
                try {
                    Class<?> sl = Class.forName("org.mozilla.geckoview.ScreenLength");
                    Object x = sl.getMethod("fromPixels", double.class).invoke(null, 0.0);
                    Object y = sl.getMethod("fromPixels", double.class).invoke(null, (double) delta);
                    Object pzc = session.getPanZoomController();
                    pzc.getClass().getMethod("scrollBy", sl, sl).invoke(pzc, x, y);
                } catch (Throwable ignored) {
                    // touch scrolling still works
                }
            } else {
                homeView.scrollBy(0, Math.round(delta));
            }
            return true;
        }
        return super.onGenericMotionEvent(ev);
    }

    @Override
    public void onBackPressed() {
        if (webScreen.getVisibility() == View.VISIBLE) goBackOrHome();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (session != null) {
            session.close();
            session = null;
        }
        super.onDestroy();
    }
}
